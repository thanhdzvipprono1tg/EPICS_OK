#if defined(BMI160GEN_USE_CURIEIMU)
// Arduino/Genuino 101
#include "internal/ss_spi_101.cpp"

#else
#include "internal/ss_spi_gen.cpp"

#endif
